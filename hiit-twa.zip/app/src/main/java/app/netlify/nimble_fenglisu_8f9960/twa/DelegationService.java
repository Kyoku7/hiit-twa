package app.netlify.nimble_fenglisu_8f9960.twa;



public class DelegationService extends
        com.google.androidbrowserhelper.trusted.DelegationService {
    @Override
    public void onCreate() {
        super.onCreate();

        
    }
}

